This is just a location to test new code and ideas without cluttering
rest of the code directory
